<?php  
include 'assets/body/upper.php';
include 'includes/sms_db.php';
 $query ="SELECT * FROM guidance_reservation_table ORDER BY ID DESC";  
 $result = mysqli_query($conn, $query);  
 ?>
<section class="home-section ms-3 p-5 bg-light rounded shadow">
 <!-- -----------------------------------------------------------------------edit here---------------------------------------------------------------------------------------- -->
 <div class="page-breadcrumb border-bottom border-dark mb-3">
                <div class="row align-items-center">
                    <div class="col-5">
                    <div class="d-flex align-items-start">
                        <ion-icon class="me-2" size="large" style="color:#C58940"  name="school-sharp"></ion-icon>
                        <h4 class="text-dark fw-bold">Scholarship</h4>
                        </div>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Scholarship</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

        

 <!-- -----------------------------------------------------------------------edit here---------------------------------------------------------------------------------------- -->
</section>


<?php
   include 'assets/body/lower.php';
?>


