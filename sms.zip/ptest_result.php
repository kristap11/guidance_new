<?php
include('includes/sms_db.php');
if(isset($_POST['submit'])) {
    $stud_id = $_POST['stud_id'];
    $name = $_POST['name'];
	$type = $_POST['type'];
	$profile = $_POST['profile'];
	$meaning = $_POST['meaning'];
    $percentage = $_POST['percentage'];
	$description = $_POST['description'];


	$sql = $conn -> prepare ("INSERT INTO guidance_stud_eval (stud_id,name,type,profile,meaning,percentage,description)VALUES(?,?,?,?,?,?,?)");
	$sql->execute(array($stud_id,$name,$type,$profile,$meaning,$percentage,$description));
        echo
        "
        <script>
            alert('successfully added');
            document.location.href = 'student_evaluation.php';
        </script>
        ";

}


