<?php
  include 'assets/body/upper.php';
?>

<section class="home-section ms-3 p-3">
   <!--------------------------------------------------------------------------edit here------------------------------------------------------------------------------------------->
   <div class="card p-3 border-0 mb-3 rounded-0  mb-2 shadow">
    <div class="card-body">
      <div class="page-breadcrumb border-bottom border-dark">
                <div class="row align-items-center">
                    <div class="col-5">
                    <div class="d-flex align-items-start">
                      <ion-icon class="me-2" size="large" style="color:#1C82AD" name="analytics-sharp"></ion-icon>
                        <h4 class="text-dark fw-bold">Reports</h4>
                      </div>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Reports</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
          </div>
        </div>
          
   <div class="row">
      <div class="col">
         <div class="card border-0 rounded-0 shadow">
            <div class="card-body">
                <div class="border-bottom border-secondary mb-3">
                    <h5 class="fw-bold"><ion-icon class="me-2" size="small" style="color:#C060A1;" name="stats-chart-sharp"></ion-icon>Appointment Report</h5>
                </div>
               <div class="row">
                   <div class="col">
                           <table class="table table-bordered mytable">
                               <thead>
                                 <tr>
                                    <th>Month</th>
                                    <th>Number of Appointments</th>
                                 </tr>
                                </thead>
                              <tbody>
                                 <tr>
                                    <td>January</td>
                                    <td>15000</td>
                                 </tr>
                                 <tr>
                                    <td>February</td>
                                    <td>23000</td>
                                 </tr>
                                 <tr>
                                    <td>March</td>
                                    <td>5500</td>
                                 </tr>
                                 <tr>
                                    <td>April</td>
                                    <td>17000</td>
                                 </tr>
                                 <tr>
                                    <td>May</td>
                                    <td>25000</td>
                                 </tr>
                                 <tr>
                                    <td>June</td>
                                    <td>30000</td>
                                 </tr>
                                 <tr>
                                    <td>July</td>
                                    <td>2000</td>
                                 </tr>
                                 <tr>
                                    <td>August</td>
                                    <td>15000</td>
                                 </tr>
                                 <tr>
                                    <td>September</td>
                                    <td>22000</td>
                                 </tr>
                                 <tr>
                                    <td>October</td>
                                    <td>34000</td>
                                 </tr>
                                 <tr>
                                    <td>November</td>
                                    <td>35000</td>
                                 </tr>
                                 <tr>
                                    <td>December</td>
                                    <td>55000</td>
                                 </tr>
                              </tbody>
                           </table>
                </div>
                    <div class="col">
                        <canvas id="bargraph" height="400"></canvas>
                    </div>
               </div>
            </div>
         </div>
      </div>

      <div class="col">
         <div class="card border-0 rounded-0 shadow">
            <div class="card-body">
                <div class="border-bottom border-secondary mb-3">
                    <h5 class="fw-bold"><ion-icon class="me-2" size="small" style="color:#6C00FF;" name="pie-chart-sharp"></ion-icon>Referral Report</h5>
                </div>
                 <div class="row">
                     <div class="col">
                           <table class="table table-bordered mytable">
                               <thead>
                                 <tr>
                                    <th>Reason for Referral</th>
                                    <th>Number of Reports</th>
                                 </tr>
                                </thead>
                              <tbody>
                                 <tr>
                                    <td>Bullying</td>
                                    <td>25</td>
                                 </tr>
                                 <tr>
                                    <td>Fear</td>
                                    <td>30</td>
                                 </tr>
                                 <tr>
                                    <td>Depression</td>
                                    <td>10</td>
                                 </tr>
                                 <tr>
                                    <td>Mental Health</td>
                                    <td>20</td>
                                 </tr>
                                 <tr>
                                    <td>Lying</td>
                                    <td>15</td>
                                 </tr>
                                 <tr>
                                    <td>Stressed</td>
                                    <td>30</td>
                                 </tr>
                                 <tr>
                                    <td><strong>Total</strong></td>
                                    <td><strong>130</strong></td>
                                 </tr>
                              </tbody>
                           </table>
                     </div>
                 <div class="col">
                           <canvas id="chartjs-pie" height="250"></canvas>
                  </div>
                </div>
            </div>
         </div>
      </div>
    </div>
    <div class="card border-0 overflow-auto mt-3 rounded-0 shadow" style="height:650px;">
        <div class="card-body">
            <div class="border-bottom border-secondary mb-3">
                <h5 class="fw-bold"><ion-icon class="me-2" size="small" style="color:#C6DCE4;" name="trash-sharp"></ion-icon>Rejected Appointment</h5>
            </div>
        <table id="rejected" class="table table-striped border-dark table-bordered border-1 mt-3">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Student Name</th>
                <th scope="col">Course</th>
                <th scope="col">Year & Section</th>
                <th scope="col">Referral Reason</th>
                <th scope="col">Date&Time</th>
              </tr>
            </thead>
         <tbody>
         <?php
         require 'includes/sms_db.php';
      $rows = mysqli_query($conn, "SELECT * FROM guidance_reject_table ORDER BY id DESC")
      ?>
      <?php foreach ($rows as $row) : ?>
      <tr>
      <td><?php echo $row["id"]; ?></td>
        <td><?php echo $row["firstname"];echo '&nbsp';  echo $row["lastname"];?></td>
        <td><?php echo $row["course"]; ?></td>
        <td><?php echo $row["year_section"]; ?></td>
        <td><?php echo $row["referral"]; ?></td>
        <td><?php echo $row["date"]; echo '&nbsp'; echo $row["time"];  ?></td>


      </tr>
      <?php endforeach; ?>

          </tbody>
        </table>
        </div>
    </div>





   <!--------------------------------------------------------------------------edit here------------------------------------------------------------------------------------------->
</section>

<?php
  include 'assets/body/lower.php';
?>
<!------Chart------->
<script src="assets/dist/js/chart.js"></script>
   <script>
      document.addEventListener("DOMContentLoaded", function () {
         // Bar Chart
         var barChartData = {
            labels: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "Novermber", "December"],
            datasets: [{
               label: 'Income',
               backgroundColor: 'rgb(79,129,189)',
               borderColor: 'rgba(0, 158, 251, 1)',
               borderWidth: 1,
               data: [15000, 2300, 5500, 17000, 25000, 30000, 2000, 15000, 22000, 34000, 35000, 55000]
            }]
         };

         var ctx = document.getElementById('bargraph').getContext('2d');
         window.myBar = new Chart(ctx, {
            type: 'bar',
            data: barChartData,
            options: {
               responsive: true,
               legend: {
                  display: false,
               }
            }
         });

      });
</script>

<!------Pie Graph------->
<script src="assets/dist/js/chart.js"></script>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
      // Pie chart
      new Chart(document.getElementById("chartjs-pie"), {
        type: "pie",
        data: {
          labels: ["Bullying", "Fear", "Depressed", "Mental Health", "Lying", "Stressed"],
          datasets: [{
            data: [40,25,5,15,15,30],
            backgroundColor: [
              window.theme.primary,
              window.theme.warning,
              window.theme.danger,
              window.theme.success,
              window.theme.info,
              window.theme.indigo,
            ],
            borderColor: "transparent"
          }]
        },
        options: {
          maintainAspectRatio: true,
          legend: {
            display: true
          }
        }
      });
    });
</script>
<!------Rejected------->
<script>  
 $(document).ready(function(){  
      $('#rejected').DataTable();  
 });  
 </script>  