const btn = document.querySelector('.btn')
const dc = document.querySelector('.dropdown-content')


btn.addEventListener('toggle', ()=>{
        console.log("Hello")
})

